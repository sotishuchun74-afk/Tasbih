# Tasbih App

## Faqat 2 ta amal — kompyutersiz, hech narsani ochmasdan

### 1-qadam: Yangi repository yarating
GitHub'da **New repository** tugmasini bosing, nom bering (masalan `tasbih`), **Create repository**.

### 2-qadam: Workflow faylini yarating
Repo sahifasida **Add file → Create new file** tugmasini bosing.

Fayl nomi maydoniga aynan shuni yozing (GitHub avtomatik papkalarga ajratadi):
```
.github/workflows/build_apk.yml
```

Pastdagi katta matn maydoniga ushbu arxiv ichidagi `.github/workflows/build_apk.yml` faylining
butun mazmunini koʻchirib joylang, soʻng **Commit changes**.

### 3-qadam: TasbihApp.zip faylini yuklang
Xuddi shu repo sahifasida **Add file → Upload files** tugmasini bosing.

`TasbihApp.zip` faylini **ochmasdan, oʻzgartirmasdan**, aynan shu koʻrinishda tashlang/tanlang,
soʻng **Commit changes**.

### Tayyor!
GitHub avtomatik ravishda:
- ZIP faylni ochadi
- Kerakli Android qismlarini yaratadi
- APK yigʻadi

Natijani koʻrish uchun: repo sahifasida **Actions** boʻlimiga oʻting → eng oxirgi (yashil belgili)
run'ni oching → pastda **Artifacts** qismidan **tasbih-app-release** ni yuklab oling.
Bu — telefoningizga oʻrnatiladigan tayyor APK fayl.

Jarayon 3–5 daqiqa davom etadi. Agar qizil belgi (xato) chiqsa, **Actions** ichidagi qizil
run'ni oching, ichidagi xato matnini nusxalab, Claude'ga yuboring.
