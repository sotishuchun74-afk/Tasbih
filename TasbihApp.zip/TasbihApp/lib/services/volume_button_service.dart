import 'dart:async';
import 'package:flutter/services.dart';

/// Listens to Android hardware volume button presses via a native
/// EventChannel set up in MainActivity.kt. Emits an event on every
/// volume up/down press (the native side already consumes the key
/// event so the system volume UI won't show while listening).
class VolumeButtonService {
  static const EventChannel _channel = EventChannel('tasbih/volume_button');
  static Stream<int>? _stream;

  static Stream<int> get onVolumeKey {
    _stream ??= _channel.receiveBroadcastStream().map((event) => event as int);
    return _stream!;
  }
}
