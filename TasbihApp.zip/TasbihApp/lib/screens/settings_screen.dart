import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../l10n/strings.dart';

class SettingsScreen extends StatefulWidget {
  final String language;
  final ValueChanged<String> onLanguageChanged;
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeModeChanged;

  const SettingsScreen({
    super.key,
    required this.language,
    required this.onLanguageChanged,
    required this.themeMode,
    required this.onThemeModeChanged,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  SharedPreferences? _prefs;

  bool _roundCompleteSound = true;
  bool _countSound = true;
  bool _roundCompleteVibration = true;
  bool _countVibration = true;
  double _vibrationIntensity = 0.5;
  bool _volumeButtonControl = false;

  bool _roundCompleteAlert = true;
  bool _showTimer = false;
  bool _autoCounter = false;
  int _autoCounterInterval = 2;
  bool _showCounterName = true;
  bool _showPercent = false;
  bool _lapLimit = false;
  String _lapLimitAction = 'stop'; // 'stop' | 'reset'

  bool _notificationReminder = false;
  String _notificationTime = '06:00';

  late String _language;

  @override
  void initState() {
    super.initState();
    _language = widget.language;
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _prefs = prefs;
      _roundCompleteSound = prefs.getBool('round_complete_sound') ?? true;
      _countSound = prefs.getBool('count_sound') ?? true;
      _roundCompleteVibration = prefs.getBool('round_complete_vibration') ?? true;
      _countVibration = prefs.getBool('count_vibration') ?? true;
      _vibrationIntensity = prefs.getDouble('vibration_intensity') ?? 0.5;
      _volumeButtonControl = prefs.getBool('volume_button_control') ?? false;
      _roundCompleteAlert = prefs.getBool('round_complete_alert') ?? true;
      _showTimer = prefs.getBool('show_timer') ?? false;
      _autoCounter = prefs.getBool('auto_counter') ?? false;
      _autoCounterInterval = prefs.getInt('auto_counter_interval') ?? 2;
      _showCounterName = prefs.getBool('show_counter_name') ?? true;
      _showPercent = prefs.getBool('show_percent') ?? false;
      _lapLimit = prefs.getBool('lap_limit') ?? false;
      _lapLimitAction = prefs.getString('lap_limit_action') ?? 'stop';
      _notificationReminder = prefs.getBool('notification_reminder') ?? false;
      _notificationTime = prefs.getString('notification_time') ?? '06:00';
    });
  }

  Future<void> _setBool(String key, bool value) async {
    await _prefs?.setBool(key, value);
  }

  Future<void> _setInt(String key, int value) async {
    await _prefs?.setInt(key, value);
  }

  Future<void> _setDouble(String key, double value) async {
    await _prefs?.setDouble(key, value);
  }

  Future<void> _setString(String key, String value) async {
    await _prefs?.setString(key, value);
  }

  String _tr(String key) => Strings.t(key, _language);

  Future<void> _pickNotificationTime() async {
    final parts = _notificationTime.split(':');
    final initial = TimeOfDay(hour: int.tryParse(parts[0]) ?? 6, minute: int.tryParse(parts[1]) ?? 0);
    final picked = await showTimePicker(context: context, initialTime: initial);
    if (picked != null) {
      final formatted =
          '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
      setState(() => _notificationTime = formatted);
      _setString('notification_time', formatted);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_tr('settings'))),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          _sectionHeader(_tr('sound_vibration')),
          SwitchListTile(
            title: Text(_tr('round_complete_sound')),
            value: _roundCompleteSound,
            onChanged: (v) {
              setState(() => _roundCompleteSound = v);
              _setBool('round_complete_sound', v);
            },
          ),
          SwitchListTile(
            title: Text(_tr('count_sound')),
            value: _countSound,
            onChanged: (v) {
              setState(() => _countSound = v);
              _setBool('count_sound', v);
            },
          ),
          SwitchListTile(
            title: Text(_tr('round_complete_vibration')),
            value: _roundCompleteVibration,
            onChanged: (v) {
              setState(() => _roundCompleteVibration = v);
              _setBool('round_complete_vibration', v);
            },
          ),
          SwitchListTile(
            title: Text(_tr('count_vibration')),
            value: _countVibration,
            onChanged: (v) {
              setState(() => _countVibration = v);
              _setBool('count_vibration', v);
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_tr('vibration_intensity')),
                Slider(
                  value: _vibrationIntensity,
                  min: 0.1,
                  max: 1.0,
                  divisions: 9,
                  label: '${(_vibrationIntensity * 100).round()}%',
                  onChanged: (v) {
                    setState(() => _vibrationIntensity = v);
                    _setDouble('vibration_intensity', v);
                  },
                ),
              ],
            ),
          ),
          SwitchListTile(
            title: Text(_tr('volume_button_control')),
            value: _volumeButtonControl,
            onChanged: (v) {
              setState(() => _volumeButtonControl = v);
              _setBool('volume_button_control', v);
            },
          ),
          const Divider(),
          _sectionHeader(_tr('display_alerts')),
          SwitchListTile(
            title: Text(_tr('round_complete_alert')),
            value: _roundCompleteAlert,
            onChanged: (v) {
              setState(() => _roundCompleteAlert = v);
              _setBool('round_complete_alert', v);
            },
          ),
          SwitchListTile(
            title: Text(_tr('show_timer')),
            value: _showTimer,
            onChanged: (v) {
              setState(() => _showTimer = v);
              _setBool('show_timer', v);
            },
          ),
          SwitchListTile(
            title: Text(_tr('auto_counter')),
            value: _autoCounter,
            onChanged: (v) {
              setState(() => _autoCounter = v);
              _setBool('auto_counter', v);
            },
          ),
          if (_autoCounter)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Text('${_autoCounterInterval}s'),
                  Expanded(
                    child: Slider(
                      value: _autoCounterInterval.toDouble(),
                      min: 1,
                      max: 10,
                      divisions: 9,
                      onChanged: (v) {
                        setState(() => _autoCounterInterval = v.round());
                        _setInt('auto_counter_interval', v.round());
                      },
                    ),
                  ),
                ],
              ),
            ),
          SwitchListTile(
            title: Text(_tr('show_counter_name')),
            value: _showCounterName,
            onChanged: (v) {
              setState(() => _showCounterName = v);
              _setBool('show_counter_name', v);
            },
          ),
          SwitchListTile(
            title: Text(_tr('show_percent')),
            value: _showPercent,
            onChanged: (v) {
              setState(() => _showPercent = v);
              _setBool('show_percent', v);
            },
          ),
          SwitchListTile(
            title: Text(_tr('lap_limit')),
            value: _lapLimit,
            onChanged: (v) {
              setState(() => _lapLimit = v);
              _setBool('lap_limit', v);
            },
          ),
          if (_lapLimit)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SegmentedButton<String>(
                segments: [
                  ButtonSegment(value: 'stop', label: Text(_tr('lap_limit_stop'))),
                  ButtonSegment(value: 'reset', label: Text(_tr('lap_limit_reset'))),
                ],
                selected: {_lapLimitAction},
                onSelectionChanged: (s) {
                  setState(() => _lapLimitAction = s.first);
                  _setString('lap_limit_action', s.first);
                },
              ),
            ),
          const Divider(),
          _sectionHeader(_tr('general_notifications')),
          ListTile(
            title: Text(_tr('language')),
            trailing: SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'uz', label: Text('Oʻzbekcha')),
                ButtonSegment(value: 'en', label: Text('English')),
              ],
              selected: {_language},
              onSelectionChanged: (s) {
                setState(() => _language = s.first);
                widget.onLanguageChanged(s.first);
              },
            ),
          ),
          SwitchListTile(
            title: Text(_tr('notification_reminder')),
            value: _notificationReminder,
            onChanged: (v) {
              setState(() => _notificationReminder = v);
              _setBool('notification_reminder', v);
            },
          ),
          if (_notificationReminder)
            ListTile(
              title: Text(_tr('notification_time')),
              subtitle: Text(_tr('notification_note'),
                  style: Theme.of(context).textTheme.bodySmall),
              trailing: TextButton(
                onPressed: _pickNotificationTime,
                child: Text(_notificationTime),
              ),
            ),
          const Divider(),
          _sectionHeader(_tr('theme')),
          RadioListTile<ThemeMode>(
            title: Text(_tr('system')),
            value: ThemeMode.system,
            groupValue: widget.themeMode,
            onChanged: (v) => widget.onThemeModeChanged(v!),
          ),
          RadioListTile<ThemeMode>(
            title: Text(_tr('light')),
            value: ThemeMode.light,
            groupValue: widget.themeMode,
            onChanged: (v) => widget.onThemeModeChanged(v!),
          ),
          RadioListTile<ThemeMode>(
            title: Text(_tr('dark')),
            value: ThemeMode.dark,
            groupValue: widget.themeMode,
            onChanged: (v) => widget.onThemeModeChanged(v!),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _sectionHeader(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
        child: Text(
          text,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
        ),
      );
}
