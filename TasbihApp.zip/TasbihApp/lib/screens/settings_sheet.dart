import 'package:flutter/material.dart';

class SettingsSheet extends StatelessWidget {
  final bool soundOn;
  final bool vibrationOn;
  final ThemeMode themeMode;
  final ValueChanged<bool> onSoundChanged;
  final ValueChanged<bool> onVibrationChanged;
  final ValueChanged<ThemeMode> onThemeModeChanged;

  const SettingsSheet({
    super.key,
    required this.soundOn,
    required this.vibrationOn,
    required this.themeMode,
    required this.onSoundChanged,
    required this.onVibrationChanged,
    required this.onThemeModeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Sozlamalar', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tebranish (vibration)'),
              value: vibrationOn,
              onChanged: onVibrationChanged,
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Ovoz'),
              value: soundOn,
              onChanged: onSoundChanged,
            ),
            const SizedBox(height: 8),
            Text('Mavzu', style: Theme.of(context).textTheme.titleMedium),
            RadioListTile<ThemeMode>(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tizim bo\'yicha'),
              value: ThemeMode.system,
              groupValue: themeMode,
              onChanged: (v) => onThemeModeChanged(v!),
            ),
            RadioListTile<ThemeMode>(
              contentPadding: EdgeInsets.zero,
              title: const Text('Kunduzgi'),
              value: ThemeMode.light,
              groupValue: themeMode,
              onChanged: (v) => onThemeModeChanged(v!),
            ),
            RadioListTile<ThemeMode>(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tungi'),
              value: ThemeMode.dark,
              groupValue: themeMode,
              onChanged: (v) => onThemeModeChanged(v!),
            ),
          ],
        ),
      ),
    );
  }
}
