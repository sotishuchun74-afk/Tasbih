import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vibration/vibration.dart';
import '../models/dhikr.dart';
import '../widgets/counter_button.dart';
import '../widgets/dhikr_selector.dart';
import 'settings_sheet.dart';

class CounterScreen extends StatefulWidget {
  final ThemeMode currentThemeMode;
  final ValueChanged<ThemeMode> onThemeModeChanged;

  const CounterScreen({
    super.key,
    required this.currentThemeMode,
    required this.onThemeModeChanged,
  });

  @override
  State<CounterScreen> createState() => _CounterScreenState();
}

class _CounterScreenState extends State<CounterScreen> {
  int _selectedIndex = 0;
  int _count = 0;
  int _dhikrTotal = 0; // shu zikr uchun umumiy (barcha vaqtlardagi) sanoq
  int _target = 0;
  bool _soundOn = true;
  bool _vibrationOn = true;
  bool? _hasVibrator;

  SharedPreferences? _prefs;

  @override
  void initState() {
    super.initState();
    _checkVibrator();
    _loadState();
  }

  Future<void> _checkVibrator() async {
    final has = await Vibration.hasVibrator();
    if (mounted) setState(() => _hasVibrator = has);
  }

  Future<void> _loadState() async {
    final prefs = await SharedPreferences.getInstance();
    final index = prefs.getInt('selected_index') ?? 0;
    setState(() {
      _prefs = prefs;
      _selectedIndex = index;
      _soundOn = prefs.getBool('sound_on') ?? true;
      _vibrationOn = prefs.getBool('vibration_on') ?? true;
    });
    _loadDhikrState(index);
  }

  void _loadDhikrState(int index) {
    final prefs = _prefs;
    if (prefs == null) return;
    setState(() {
      _count = prefs.getInt('count_$index') ?? 0;
      _dhikrTotal = prefs.getInt('dhikr_total_$index') ?? 0;
      _target = prefs.getInt('target_$index') ?? dhikrList[index].target;
    });
  }

  Future<void> _saveCount() async {
    await _prefs?.setInt('count_$_selectedIndex', _count);
    await _prefs?.setInt('dhikr_total_$_selectedIndex', _dhikrTotal);
  }

  Dhikr get _currentDhikr => dhikrList[_selectedIndex];

  void _increment() {
    setState(() {
      _count += 1;
      _dhikrTotal += 1;
    });
    _saveCount();
    _giveFeedback();
  }

  Future<void> _giveFeedback() async {
    final isMilestone = _target > 0 && _count % _target == 0;

    if (_vibrationOn) {
      final canCustomVibrate = _hasVibrator ?? false;
      if (canCustomVibrate) {
        if (isMilestone) {
          Vibration.vibrate(pattern: [0, 220, 100, 220]);
        } else {
          Vibration.vibrate(duration: 35);
        }
      } else {
        if (isMilestone) {
          HapticFeedback.heavyImpact();
          Future.delayed(const Duration(milliseconds: 150), () => HapticFeedback.heavyImpact());
        } else {
          HapticFeedback.lightImpact();
        }
      }
    }
    if (_soundOn) {
      SystemSound.play(SystemSoundType.click);
    }
  }

  void _selectDhikr(int index) async {
    await _prefs?.setInt('selected_index', index);
    setState(() => _selectedIndex = index);
    _loadDhikrState(index);
  }

  Future<void> _confirmReset() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sanoqni tozalash'),
        content: Text('"${_currentDhikr.name}" joriy sanog\'ini 0 ga tushirishni tasdiqlaysizmi? ("Jami" saqlanib qoladi)'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Bekor qilish')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Ha, tozalash')),
        ],
      ),
    );
    if (confirmed == true) {
      setState(() => _count = 0);
      _saveCount();
      if (_vibrationOn) HapticFeedback.mediumImpact();
    }
  }

  Future<void> _editTarget() async {
    final controller = TextEditingController(text: _target > 0 ? '$_target' : '');
    final result = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Maqsadni oʻzgartirish'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Masalan: 33, 99, 100...',
            labelText: 'Maqsad soni',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Bekor qilish')),
          FilledButton(
            onPressed: () {
              final value = int.tryParse(controller.text.trim()) ?? 0;
              Navigator.pop(context, value < 0 ? 0 : value);
            },
            child: const Text('Saqlash'),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() => _target = result);
      await _prefs?.setInt('target_$_selectedIndex', result);
    }
  }

  void _openSettings() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SettingsSheet(
        soundOn: _soundOn,
        vibrationOn: _vibrationOn,
        themeMode: widget.currentThemeMode,
        onSoundChanged: (v) {
          setState(() => _soundOn = v);
          _prefs?.setBool('sound_on', v);
        },
        onVibrationChanged: (v) {
          setState(() => _vibrationOn = v);
          _prefs?.setBool('vibration_on', v);
        },
        onThemeModeChanged: widget.onThemeModeChanged,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tasbih'),
        actions: [
          IconButton(icon: const Icon(Icons.settings_outlined), onPressed: _openSettings),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),
            DhikrSelector(selectedIndex: _selectedIndex, onSelect: _selectDhikr),
            const SizedBox(height: 12),
            if (_currentDhikr.arabic.isNotEmpty)
              Text(_currentDhikr.arabic, style: TextStyle(fontSize: 26, color: scheme.secondary)),
            Text(
              _currentDhikr.name,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600),
            ),
            InkWell(
              onTap: _editTarget,
              borderRadius: BorderRadius.circular(20),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _target > 0 ? 'Maqsad: $_target' : 'Maqsad: cheklanmagan',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(width: 4),
                    Icon(Icons.edit, size: 15, color: scheme.secondary),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '$_count',
                      style: TextStyle(
                        fontSize: 72,
                        fontWeight: FontWeight.bold,
                        color: scheme.primary,
                      ),
                    ),
                    const SizedBox(height: 24),
                    CounterButton(onTap: _increment),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Jami (${_currentDhikr.name}): $_dhikrTotal', style: Theme.of(context).textTheme.bodyMedium),
                  OutlinedButton.icon(
                    onPressed: _confirmReset,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Tozalash'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
