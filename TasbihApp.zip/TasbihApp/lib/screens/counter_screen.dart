import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vibration/vibration.dart';
import '../l10n/strings.dart';
import '../models/dhikr.dart';
import '../services/volume_button_service.dart';
import '../widgets/counter_button.dart';
import '../widgets/dhikr_selector.dart';
import 'settings_screen.dart';

class CounterScreen extends StatefulWidget {
  final ThemeMode currentThemeMode;
  final ValueChanged<ThemeMode> onThemeModeChanged;
  final String language;
  final ValueChanged<String> onLanguageChanged;

  const CounterScreen({
    super.key,
    required this.currentThemeMode,
    required this.onThemeModeChanged,
    required this.language,
    required this.onLanguageChanged,
  });

  @override
  State<CounterScreen> createState() => _CounterScreenState();
}

class _CounterScreenState extends State<CounterScreen> {
  int _selectedIndex = 0;
  int _count = 0;
  int _dhikrTotal = 0;
  int _target = 0;
  int _rounds = 0;
  bool _lapLocked = false;

  // settings mirrors
  bool _roundCompleteSound = true;
  bool _countSound = true;
  bool _roundCompleteVibration = true;
  bool _countVibration = true;
  double _vibrationIntensity = 0.5;
  bool _volumeButtonControl = false;
  bool _roundCompleteAlert = true;
  bool _showTimer = false;
  bool _autoCounter = false;
  int _autoCounterInterval = 2;
  bool _showCounterName = true;
  bool _showPercent = false;
  bool _lapLimit = false;
  String _lapLimitAction = 'stop';

  bool? _hasVibrator;
  SharedPreferences? _prefs;

  Timer? _stopwatchTimer;
  Duration _elapsed = Duration.zero;
  Timer? _autoCounterTimer;
  StreamSubscription<int>? _volumeSub;

  @override
  void initState() {
    super.initState();
    _checkVibrator();
    _loadEverything();
    _startStopwatch();
  }

  @override
  void dispose() {
    _stopwatchTimer?.cancel();
    _autoCounterTimer?.cancel();
    _volumeSub?.cancel();
    super.dispose();
  }

  String _tr(String key) => Strings.t(key, widget.language);

  Future<void> _checkVibrator() async {
    final has = await Vibration.hasVibrator();
    if (mounted) setState(() => _hasVibrator = has);
  }

  void _startStopwatch() {
    _stopwatchTimer?.cancel();
    _stopwatchTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _elapsed += const Duration(seconds: 1));
    });
  }

  Future<void> _loadEverything() async {
    final prefs = await SharedPreferences.getInstance();
    final index = prefs.getInt('selected_index') ?? 0;
    _prefs = prefs;
    setState(() {
      _selectedIndex = index;
      _roundCompleteSound = prefs.getBool('round_complete_sound') ?? true;
      _countSound = prefs.getBool('count_sound') ?? true;
      _roundCompleteVibration = prefs.getBool('round_complete_vibration') ?? true;
      _countVibration = prefs.getBool('count_vibration') ?? true;
      _vibrationIntensity = prefs.getDouble('vibration_intensity') ?? 0.5;
      _volumeButtonControl = prefs.getBool('volume_button_control') ?? false;
      _roundCompleteAlert = prefs.getBool('round_complete_alert') ?? true;
      _showTimer = prefs.getBool('show_timer') ?? false;
      _autoCounter = prefs.getBool('auto_counter') ?? false;
      _autoCounterInterval = prefs.getInt('auto_counter_interval') ?? 2;
      _showCounterName = prefs.getBool('show_counter_name') ?? true;
      _showPercent = prefs.getBool('show_percent') ?? false;
      _lapLimit = prefs.getBool('lap_limit') ?? false;
      _lapLimitAction = prefs.getString('lap_limit_action') ?? 'stop';
    });
    _loadDhikrState(index);
    _applyAutoCounter();
    _applyVolumeButton();
  }

  void _loadDhikrState(int index) {
    final prefs = _prefs;
    if (prefs == null) return;
    setState(() {
      _count = prefs.getInt('count_$index') ?? 0;
      _dhikrTotal = prefs.getInt('dhikr_total_$index') ?? 0;
      _target = prefs.getInt('target_$index') ?? dhikrList[index].target;
      _rounds = prefs.getInt('rounds_$index') ?? 0;
      _lapLocked = false;
      _elapsed = Duration.zero;
    });
  }

  Future<void> _saveCount() async {
    await _prefs?.setInt('count_$_selectedIndex', _count);
    await _prefs?.setInt('dhikr_total_$_selectedIndex', _dhikrTotal);
    await _prefs?.setInt('rounds_$_selectedIndex', _rounds);
  }

  Dhikr get _currentDhikr => dhikrList[_selectedIndex];

  void _applyAutoCounter() {
    _autoCounterTimer?.cancel();
    if (_autoCounter) {
      _autoCounterTimer = Timer.periodic(Duration(seconds: _autoCounterInterval), (_) {
        _increment();
      });
    }
  }

  void _applyVolumeButton() {
    _volumeSub?.cancel();
    if (_volumeButtonControl) {
      _volumeSub = VolumeButtonService.onVolumeKey.listen((_) => _increment());
    }
  }

  void _increment() {
    if (_lapLocked) return;
    setState(() {
      _count += 1;
      _dhikrTotal += 1;
    });

    final reachedTarget = _target > 0 && _count % _target == 0;

    if (reachedTarget) {
      setState(() => _rounds += 1);
    }

    _saveCount();
    _giveFeedback(reachedTarget);

    if (reachedTarget && _roundCompleteAlert) {
      _showRoundCompleteDialog();
    }

    if (reachedTarget && _lapLimit) {
      if (_lapLimitAction == 'reset') {
        Future.delayed(const Duration(milliseconds: 200), () {
          if (mounted) {
            setState(() => _count = 0);
            _saveCount();
          }
        });
      } else {
        setState(() => _lapLocked = true);
      }
    }
  }

  Future<void> _giveFeedback(bool isMilestone) async {
    final wantVibration = isMilestone ? _roundCompleteVibration : _countVibration;
    if (wantVibration) {
      final canCustomVibrate = _hasVibrator ?? false;
      final baseDuration = (35 + _vibrationIntensity * 65).round(); // 35..100ms
      if (canCustomVibrate) {
        if (isMilestone) {
          final amp = (_vibrationIntensity * 255).round().clamp(1, 255);
          Vibration.vibrate(pattern: [0, 220, 100, 220], intensities: [0, amp, 0, amp]);
        } else {
          Vibration.vibrate(duration: baseDuration);
        }
      } else {
        if (isMilestone) {
          HapticFeedback.heavyImpact();
          Future.delayed(const Duration(milliseconds: 150), () => HapticFeedback.heavyImpact());
        } else {
          HapticFeedback.lightImpact();
        }
      }
    }
    final wantSound = isMilestone ? _roundCompleteSound : _countSound;
    if (wantSound) {
      SystemSound.play(SystemSoundType.click);
    }
  }

  void _showRoundCompleteDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(_tr('congrats')),
        content: Text('${_tr('target_reached')}: ${_currentDhikr.name} ($_target)'),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(context), child: Text(_tr('ok'))),
        ],
      ),
    );
  }

  void _selectDhikr(int index) async {
    await _prefs?.setInt('selected_index', index);
    setState(() => _selectedIndex = index);
    _loadDhikrState(index);
  }

  Future<void> _confirmReset() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(_tr('confirm_reset')),
        content: Text('"${_currentDhikr.name}" ${_tr('confirm_reset_body')}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(_tr('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(_tr('yes_clear'))),
        ],
      ),
    );
    if (confirmed == true) {
      setState(() {
        _count = 0;
        _lapLocked = false;
        _elapsed = Duration.zero;
      });
      _saveCount();
      if (_countVibration) HapticFeedback.mediumImpact();
    }
  }

  Future<void> _editTarget() async {
    final controller = TextEditingController(text: _target > 0 ? '$_target' : '');
    final result = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(_tr('edit_target_title')),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          autofocus: true,
          decoration: InputDecoration(hintText: _tr('edit_target_hint')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text(_tr('cancel'))),
          FilledButton(
            onPressed: () {
              final value = int.tryParse(controller.text.trim()) ?? 0;
              Navigator.pop(context, value < 0 ? 0 : value);
            },
            child: Text(_tr('save')),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() => _target = result);
      await _prefs?.setInt('target_$_selectedIndex', result);
    }
  }

  Future<void> _openSettings() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SettingsScreen(
          language: widget.language,
          onLanguageChanged: widget.onLanguageChanged,
          themeMode: widget.currentThemeMode,
          onThemeModeChanged: widget.onThemeModeChanged,
        ),
      ),
    );
    // Settings might have changed behavior-affecting values; reload them.
    await _loadEverything();
  }

  String _formatElapsed(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final percent = _target > 0 ? ((_count / _target) * 100).clamp(0, 999).round() : 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(_tr('app_title')),
        actions: [
          IconButton(icon: const Icon(Icons.settings_outlined), onPressed: _openSettings),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),
            DhikrSelector(selectedIndex: _selectedIndex, onSelect: _selectDhikr),
            const SizedBox(height: 12),
            if (_showCounterName) ...[
              if (_currentDhikr.arabic.isNotEmpty)
                Text(_currentDhikr.arabic, style: TextStyle(fontSize: 26, color: scheme.secondary)),
              Text(
                _currentDhikr.name,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
            InkWell(
              onTap: _editTarget,
              borderRadius: BorderRadius.circular(20),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _target > 0 ? '${_tr('target')}: $_target' : '${_tr('target')}: ${_tr('unlimited')}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(width: 4),
                    Icon(Icons.edit, size: 15, color: scheme.secondary),
                  ],
                ),
              ),
            ),
            if (_showTimer)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(_formatElapsed(_elapsed), style: Theme.of(context).textTheme.bodySmall),
              ),
            Wrap(
              spacing: 12,
              children: [
                Text('${_tr('rounds_label')}: $_rounds', style: Theme.of(context).textTheme.bodySmall),
                if (_showPercent && _target > 0)
                  Text('$percent%', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '$_count',
                      style: TextStyle(fontSize: 72, fontWeight: FontWeight.bold, color: scheme.primary),
                    ),
                    const SizedBox(height: 24),
                    CounterButton(onTap: _increment),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${_tr('total_for')} (${_currentDhikr.name}): $_dhikrTotal',
                      style: Theme.of(context).textTheme.bodyMedium),
                  OutlinedButton.icon(
                    onPressed: _confirmReset,
                    icon: const Icon(Icons.refresh),
                    label: Text(_tr('reset')),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
