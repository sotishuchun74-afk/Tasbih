class Dhikr {
  final String name;
  final String arabic;
  final int target;

  const Dhikr({required this.name, required this.arabic, required this.target});
}

const List<Dhikr> dhikrList = [
  Dhikr(name: 'Subhanalloh', arabic: 'سُبْحَانَ اللَّهِ', target: 33),
  Dhikr(name: 'Alhamdulillah', arabic: 'الْحَمْدُ لِلَّهِ', target: 33),
  Dhikr(name: 'Allohu Akbar', arabic: 'اللَّهُ أَكْبَرُ', target: 34),
  Dhikr(name: 'La ilaha illalloh', arabic: 'لَا إِلَٰهَ إِلَّا اللَّهُ', target: 100),
  Dhikr(name: 'Astag\'firulloh', arabic: 'أَسْتَغْفِرُ اللَّهُ', target: 100),
  Dhikr(name: 'Erkin sanoq', arabic: '', target: 0),
];
