import 'package:flutter/material.dart';
import '../models/dhikr.dart';

class DhikrSelector extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  const DhikrSelector({super.key, required this.selectedIndex, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: dhikrList.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final isSelected = index == selectedIndex;
          return ChoiceChip(
            label: Text(dhikrList[index].name),
            selected: isSelected,
            onSelected: (_) => onSelect(index),
            selectedColor: scheme.primary,
            labelStyle: TextStyle(
              color: isSelected ? scheme.onPrimary : scheme.onSurface,
              fontWeight: FontWeight.w600,
            ),
            backgroundColor: scheme.surfaceVariant.withOpacity(0.4),
            shape: StadiumBorder(side: BorderSide(color: scheme.secondary.withOpacity(0.5))),
          );
        },
      ),
    );
  }
}
